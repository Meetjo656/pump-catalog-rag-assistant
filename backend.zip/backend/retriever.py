
import os, pickle, faiss, numpy as np
from dotenv import load_dotenv
from google import genai
from google.genai import types
from pump_master import resolve_model_identifier

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

VECTOR_DIR = os.path.join(BASE_DIR, "vector_store")
INDEX_PATH = os.path.join(VECTOR_DIR, "pump_index.faiss")
DOCS_PATH = os.path.join(VECTOR_DIR, "pump_documents.pkl")
META_PATH = os.path.join(VECTOR_DIR, "pump_metadata.pkl")

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
EMBED_MODEL = "text-embedding-004"

def retrieve_top_k(query, k=5, model_filter=None, chunk_type=None):
    index = faiss.read_index(INDEX_PATH)
    docs = pickle.load(open(DOCS_PATH, "rb"))
    meta = pickle.load(open(META_PATH, "rb"))

    resolved = resolve_model_identifier(model_filter)

    emb = client.models.embed_content(
        model=EMBED_MODEL,
        contents=[query],
        config=types.EmbedContentConfig(task_type="RETRIEVAL_QUERY"),
    )

    q = np.array([emb.embeddings[0].values], dtype="float32")
    D, I = index.search(q, k * 4)

    out = []
    for i, idx in enumerate(I[0]):
        if idx < 0:
            continue
        m = meta[idx]
        if resolved and m["model"] not in (resolved, "ALL"):
            continue
        if chunk_type and m["chunk_type"] != chunk_type:
            continue
        out.append({"text": docs[idx], "model": m["model"]})
        if len(out) >= k:
            break
    return out
