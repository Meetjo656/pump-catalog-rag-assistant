
import subprocess

def build_prompt(question, chunks):
    if not chunks:
        return None

    models = {c["model"] for c in chunks if c["model"] != "ALL"}
    if len(models) > 1:
        return None

    context = "\n\n".join(c["text"] for c in chunks)
    return f"""Use ONLY the context below.
If not found, say: Information not available.

CONTEXT:
{context}

QUESTION:
{question}

ANSWER:
"""

def generate_answer(prompt):
    if not prompt:
        return "Information not available."

    p = subprocess.run(
        ["ollama", "run", "llama3.1:8b"],
        input=prompt.encode("utf-8"),
        stdout=subprocess.PIPE,
    )
    return p.stdout.decode("utf-8").strip()
