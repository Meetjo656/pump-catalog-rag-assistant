
from retriever import retrieve_top_k
from generation import build_prompt, generate_answer
from pump_master import resolve_model_identifier

def _run(question, model=None, chunk=None):
    chunks = retrieve_top_k(question, model_filter=model, chunk_type=chunk)
    prompt = build_prompt(question, chunks)
    return generate_answer(prompt)

def rag_view_specs(p):
    mid = resolve_model_identifier(p.get("modelA"))
    if not mid:
        return "Information not available."
    return _run(f"List technical specifications of pump {mid}.", mid, "specifications")

def rag_explain_suitability(p):
    mid = resolve_model_identifier(p.get("modelA"))
    app = p.get("application", "general use")
    if not mid:
        return "Information not available."
    return _run(f"Explain suitability of pump {mid} for {app}.", mid, "features")

def rag_compare_models(p):
    m1 = resolve_model_identifier(p.get("modelA"))
    m2 = resolve_model_identifier(p.get("modelB"))
    if not m1 or not m2 or m1 == m2:
        return "Information not available."
    return _run(f"Compare pump {m1} and {m2}.", None, "features")

def rag_installation_guidance(p):
    mid = resolve_model_identifier(p.get("modelA"))
    return _run(f"Installation guidance for pump {mid}.", mid, "installation")

def rag_free_text(q):
    return _run(q)
